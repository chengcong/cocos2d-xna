﻿#if PCL
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICSharpCode.SharpZipLib.VirtualFileSystem
{
    /// <summary>
    /// Directory informations
    /// </summary>
    public interface IDirectoryInfo : IVfsElement
    {
    }
}
#endif

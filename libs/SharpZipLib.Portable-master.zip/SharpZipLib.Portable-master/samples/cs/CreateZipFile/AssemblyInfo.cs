using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("CreateZipFile")]
[assembly: AssemblyDescription("Free C# IDE")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("A SharpDevelop sample")]
[assembly: AssemblyCopyright("Mike Krueger 2000")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("0.85.4.369")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
